package apiTesting;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

public class BaseCls {
	
	static RequestSpecification ReqSpec=new RequestSpecBuilder().setBaseUri("https://reference-tryout-api.herokuapp.com").build();
	public static  int ActStatusCode=200;
	public static  int ActInternalserverstatusCode=500;
	public static  int ActNoContentStatusCode =204;
	public static  int ActGatewayTimeoutStatusCode =504;
	public static String ActMediaType = "application/json";
	public static String ActText="137";
	 static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");  
	   static LocalDateTime now = LocalDateTime.now();  
	   public static  String CurrentTime=dtf.format(now); 
	    
	
	
	
}

