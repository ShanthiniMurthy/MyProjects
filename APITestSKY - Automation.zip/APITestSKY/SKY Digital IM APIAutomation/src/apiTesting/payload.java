package apiTesting;

public class payload {
	

	public static String addBody() {
		
		String load = "{\r\n"
				+ "    \"test\": 137\r\n"
				+ "}";
		return load;
	}
		

}
