package apiTesting;

import io.restassured.path.json.JsonPath;

public class RawtoJson {
	public static JsonPath convertJson(String response) {
		JsonPath JsPath=new JsonPath(response);
		return JsPath;
	}


}
