package apiTesting;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.response.Response;

public class GetRequestValidation extends BaseCls {

	public static void main(String[] args) {
		
		Response InternalserverErrrRes=given().spec(ReqSpec).when().get("internal_server_error");
		Response NoContentRes=given().spec(ReqSpec).when().get("no_response");
		Response GatewayTimeoutRes=given().spec(ReqSpec).when().get("gateway_timeout");
		Response UnauthorizedRes=given().spec(ReqSpec).when().get("unauthorized");
		Response BadRequestdRes=given().spec(ReqSpec).when().get("bad_request");
		Response forbiddenRes=given().spec(ReqSpec).when().get("forbidden");
		Response ManageHealthRes=given().spec(ReqSpec).when().get("manage/health");
		
		
		  //Get Status code 
  		int InternalserverstatusCode = InternalserverErrrRes.getStatusCode();
  		int NoContentStatusCode = NoContentRes.getStatusCode();
  		int GateWayTimeOutStatusCode = GatewayTimeoutRes.getStatusCode();
  		int UnauthorizedStatusCode = UnauthorizedRes.getStatusCode();
  		int BadRequestStatusCode = BadRequestdRes.getStatusCode();
  		int forbiddenStatusCode = forbiddenRes.getStatusCode();
  		int ManageHealthStatusCode = ManageHealthRes.getStatusCode();
  		
  	//Status Code Assertion
  			Assert.assertEquals(InternalserverstatusCode,ActStatusCode );
  			Assert.assertEquals(NoContentStatusCode,ActStatusCode );
  			Assert.assertEquals(GateWayTimeOutStatusCode,ActStatusCode );
  			Assert.assertEquals(UnauthorizedStatusCode,ActStatusCode );
  			Assert.assertEquals(BadRequestStatusCode,ActStatusCode );
  			Assert.assertEquals(forbiddenStatusCode,ActStatusCode );
  			Assert.assertEquals(ManageHealthStatusCode,ActStatusCode );

  			
  			
  			System.out.print("Status Code is "+ActStatusCode+ " for GET Request is as expected");
	}

}
