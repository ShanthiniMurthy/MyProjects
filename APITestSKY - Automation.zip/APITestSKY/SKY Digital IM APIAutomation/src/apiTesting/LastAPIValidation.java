package apiTesting;

import static io.restassured.RestAssured.given;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class LastAPIValidation extends BaseCls{
	

	public static void main(String[] args) throws ParseException {
		
		
		
		Response InternalserverErrrRes=given().spec(ReqSpec).when().get("internal_server_error/last");
		Response NoContentRes=given().spec(ReqSpec).when().get("no_response/last");
		Response GatewayTimeoutRes=given().spec(ReqSpec).when().get("gateway_timeout/last");
		
		
		//Get Status code 
		int InternalserverstatusCode = InternalserverErrrRes.getStatusCode();
		int NoContentStatusCode = NoContentRes.getStatusCode();
		int GateWayTimeOutStatusCode = GatewayTimeoutRes.getStatusCode();
	
	
		//Convert Response to string 
		String InternalserverErrrResStr=InternalserverErrrRes.asPrettyString();
		String NoContenthResStr=NoContentRes.asPrettyString();
		String GatewayTimeoutResStr=GatewayTimeoutRes.asPrettyString();
		
	  //Activity parse
		JsonPath InternalserverErrrJsP=RawtoJson.convertJson(InternalserverErrrResStr);
		JsonPath NoContenthJsp=RawtoJson.convertJson(NoContenthResStr);
		JsonPath GatewayTimeoutJsp=RawtoJson.convertJson(GatewayTimeoutResStr);
		
		//Get Media type and Body Received
		String InternalserverErrrMediaType= InternalserverErrrJsP.getString("internal_server_error[1].mediaTypeUsed");
		String NoContentMediaType= NoContenthJsp.getString("no_response[1].mediaTypeUsed");
		String GatewayTimeoutMediaType= GatewayTimeoutJsp.getString("gateway_timeout[1].mediaTypeUsed");
		
		String InternalserverErrrTxt= InternalserverErrrJsP.getString("internal_server_error[1].bodyReceived.test");
		String NoContentTxt= NoContenthJsp.getString("no_response[1].bodyReceived.test");
		String GatewayTimeoutTxt= GatewayTimeoutJsp.getString("gateway_timeout[1].bodyReceived.test");

		//Get Last Update timestamp	
		String InternalserverErrrTime= InternalserverErrrJsP.getString("internal_server_error[0].lastUpdated");
		String NoContentTime= GatewayTimeoutJsp.getString("no_response[0].lastUpdated");
		String GatewayTimeoutTime= GatewayTimeoutJsp.getString("gateway_timeout[0].lastUpdated");
		
		//Format Last updated timestamp
		String FormatedNoContentTimeLastUpdatedTime = NoContentTime.substring(0,16);
		String FormatedInternalserverErrrLastUpdatedTime = InternalserverErrrTime.substring(0,16);
		String FormatedGatewayLastUpdatedTime = GatewayTimeoutTime.substring(0,16);
		
		
		//Status Code Assertion
		Assert.assertEquals(InternalserverstatusCode,ActStatusCode );
		Assert.assertEquals(NoContentStatusCode,ActStatusCode );
		Assert.assertEquals(GateWayTimeOutStatusCode,ActStatusCode );
		
		//JSON Assertion - Media Type 
		Assert.assertEquals(InternalserverErrrMediaType,ActMediaType );
		Assert.assertEquals(NoContentMediaType,ActMediaType );
		Assert.assertEquals(GatewayTimeoutMediaType,ActMediaType );
		
		//JSON Assertion - Body Received 
		Assert.assertEquals(InternalserverErrrTxt,ActText );
		Assert.assertEquals(NoContentTxt,ActText );
		Assert.assertEquals(GatewayTimeoutTxt,ActText );
		
		//Timestamp Assertion
		 Assert.assertEquals(FormatedGatewayLastUpdatedTime, CurrentTime);
		 Assert.assertEquals(FormatedInternalserverErrrLastUpdatedTime, CurrentTime);
		 Assert.assertEquals(FormatedNoContentTimeLastUpdatedTime, CurrentTime);
		
		System.out.println("Status Code is "+ActStatusCode+ " for POST Request- LastAPI Validation is as expected");
		System.out.println("Media Type is "+ActMediaType+ " for POST Request- LastAPI Validation is as expected");
		System.out.println("Body Text in the response is "+ActText+ " for POST Request- LastAPI Validation is as expected");
		
		

		
		
		  
	
		    
		  
		
	}
	

}
