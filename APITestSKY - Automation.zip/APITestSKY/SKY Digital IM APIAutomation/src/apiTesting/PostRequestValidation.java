package apiTesting;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.testng.Assert;



public class PostRequestValidation extends BaseCls {


	public static void main(String[] args) {
		
    Response InternalserverErrrRes=given().spec(ReqSpec).header("Content-Type", "application/json").body(payload.addBody()).
				                    when().post("internal_server_error");
    Response NoContentRes=given().spec(ReqSpec).header("Content-Type", "application/json").body(payload.addBody()).
                          when().post("no_response");
    Response GatewayTimeoutRes=given().spec(ReqSpec).header("Content-Type", "application/json").body(payload.addBody()).
                               when().post("gateway_timeout");
    
  //Get Status code 
  		int InternalserverstatusCode = InternalserverErrrRes.getStatusCode();
  		int NoContentStatusCode = NoContentRes.getStatusCode();
  		int GateWayTimeOutStatusCode = GatewayTimeoutRes.getStatusCode();
  		
  		
  	//Convert Response to string 
  			String InternalserverErrrResStr=InternalserverErrrRes.asPrettyString();
  			String GatewayTimeoutResStr=GatewayTimeoutRes.asPrettyString();
  			
  		  //Activity parse
  			JsonPath InternalserverErrrJsP=RawtoJson.convertJson(InternalserverErrrResStr);
  			JsonPath GatewayTimeoutJsp=RawtoJson.convertJson(GatewayTimeoutResStr);
  			
  			//Get Text
  			String InternalserverErrrTxt= InternalserverErrrJsP.getString("receivedRequest[0].test");
  			String GatewayTimeoutTxt= GatewayTimeoutJsp.getString("receivedRequest[0].test");
  			
  		
  			Assert.assertEquals(InternalserverstatusCode,ActInternalserverstatusCode );
  			Assert.assertEquals(NoContentStatusCode,ActNoContentStatusCode );
  			//Assert.assertEquals(GateWayTimeOutStatusCode,ActGatewayTimeoutStatusCode );
  			
  		  //JSON Assertion - Body Received 
  			Assert.assertEquals(InternalserverErrrTxt,ActText );
  			Assert.assertEquals(GatewayTimeoutTxt,ActText );
    
      
	//System.out.println(InternalserverstatusCode);
	System.out.print("Status Code is "+ActStatusCode+ " for GET Request is as expected");
  
	}
}
